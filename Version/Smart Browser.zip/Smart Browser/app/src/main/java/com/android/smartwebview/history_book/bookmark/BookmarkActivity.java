package com.android.smartwebview.history_book.bookmark;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.core.content.ContextCompat;

import com.android.smartwebview.R;
import com.android.smartwebview.history_book.Contact;
import com.android.smartwebview.utils.ThemeUtils;

import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class BookmarkActivity extends AppCompatActivity {

    public static final int RESULT_BookmarkActivity = 2;
    BookMark_helper db;
    ContactImageAdapter adapter;
    ListView listView;
    RelativeLayout bookmark_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ThemeUtils ut = new ThemeUtils(this);
        ut.setTheme();
        setContentView(R.layout.bookmark_layout);
        setTitle("Bookmarks");

        bookmark_layout = findViewById(R.id.bookmark_layout);

        if(ThemeUtils.isBlack()){
            // m2.getIcon().setColorFilter(new PorterDuffColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN));
            bookmark_layout.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorBlackTheme));
        }

        ArrayList<Contact> imageArry = new ArrayList<>();

        db = new BookMark_helper(this);

        // display main List view bcard and contact name

        // Reading all contacts from database
        List<Contact> contacts = db.getAllContacts();
        for (Contact cn : contacts) {
            String log = "ID:" + cn.getID() + " Name: " + cn.getName() + " Url: " + cn.getUrl()
                    + "Date:" + cn.getDate() + " ,Image: " + Arrays.toString(cn.getImage());

            // Writing Contacts to log
            Log.d("Result: ", log);
            //add contacts data in arrayList
            imageArry.add(cn);

        }
        adapter = new ContactImageAdapter(this, R.layout.activity_view_bookmark,
                imageArry);
        listView = findViewById(R.id.list_view);
        adapter.notifyDataSetChanged();
        listView.setEmptyView(findViewById(R.id.empty));

        listView.setAdapter(adapter);


        // OnCLickListiner For List Items
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long viewId) {

                TextView descTextView = view.findViewById(R.id.url);
                String bookmarkUrl = descTextView.getText().toString();

                Intent intent = new Intent();
                intent.putExtra("bookmarkUrl", bookmarkUrl);
                setResult(BookmarkActivity.RESULT_BookmarkActivity, intent);
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.history_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if (id == R.id.delete_all) {

            final TextView mCreditsTitle = new TextView(this);
            mCreditsTitle.setText("");
            mCreditsTitle.setTypeface(Typeface.DEFAULT_BOLD);
            mCreditsTitle.setTextSize(20);
            mCreditsTitle.setGravity(Gravity.CENTER_HORIZONTAL);

            AlertDialog mCreditsDialog = new AlertDialog.Builder(this)
                    .setTitle("Are you sure to Delete All Bookmarks")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            db.deleteAll(db.TABLE_NAME);
                            BookmarkActivity.this.recreate();
                        }
                    })
                    .setNegativeButton(android.R.string.cancel, null)
                    .setView(mCreditsTitle)
                    .show();

        }
        return super.onOptionsItemSelected(item);
    }


    public class ContactImageAdapter extends ArrayAdapter<Contact> {
        Context context;
        int layoutResourceId;
        // BcardImage data[] = null;
        ArrayList<Contact> data = new ArrayList<>();

        ContactImageAdapter(Context context, int layoutResourceId, ArrayList<Contact> data) {
            super(context, layoutResourceId, data);
            this.layoutResourceId = layoutResourceId;
            this.context = context;
            this.data = data;
        }

        @NonNull
        @Override
        public View getView(int position, View convertView, @NonNull ViewGroup parent) {
            View row = convertView;
            ImageHolder holder = null;

            if (row == null) {
                LayoutInflater inflater = ((Activity) context).getLayoutInflater();
                row = inflater.inflate(layoutResourceId, parent, false);

                holder = new ImageHolder();
                holder.bookmark_view = row.findViewById(R.id.bookmark_view);
                holder.txtTitle = row.findViewById(R.id.title);
                holder.txtUrl = row.findViewById(R.id.url);
                holder.imgIcon = row.findViewById(R.id.faviconTab);
                holder.time = row.findViewById(R.id.record_item_time);

                holder.buttonViewOption = row.findViewById(R.id.textViewOptions);

                row.setTag(holder);
            } else {
                holder = (ImageHolder) row.getTag();
            }

            Contact picture = data.get(position);

            holder.txtTitle.setText(picture._name);
            holder.txtUrl.setText(picture._url);

            if(ThemeUtils.isBlack()){
                holder.bookmark_view.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorBlackTheme));
                holder.txtUrl.setTextColor(ContextCompat.getColor(context,R.color.white));
                holder.txtTitle.setTextColor(ContextCompat.getColor(context,R.color.white));
                holder.imgIcon.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorBlackTheme));
                holder.buttonViewOption.setColorFilter(new PorterDuffColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN));
            }

            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd", Locale.getDefault());
            holder.time.setText(sdf.format(picture._date));

            ImageHolder finalHolder = holder;
            holder.buttonViewOption.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //creating a popup menu
                    PopupMenu popup = new PopupMenu(context, finalHolder.buttonViewOption);
                    //inflating menu from xml resource
                    popup.inflate(R.menu.menu_bookmark);
                    //adding click listener
                    popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            switch (item.getItemId()) {
                                case R.id.edit:
                                    //handle menu1 click
                                    break;
                                case R.id.delete:
                                    //handle menu3 click
                                    db.deleteURL(picture._url, db.TABLE_NAME);
                                    adapter.notifyDataSetChanged();
                                    BookmarkActivity.this.recreate();
                                    break;
                            }
                            return false;
                        }
                    });
                    //displaying the popup
                    popup.show();

                }
            });

            //convert byte to bitmap take from contact class

            byte[] outImage=picture._image;
            ByteArrayInputStream imageStream = new ByteArrayInputStream(outImage);
            Bitmap theImage = BitmapFactory.decodeStream(imageStream);
            holder.imgIcon.setImageBitmap(theImage);

            return row;

        }

        class ImageHolder {
            RelativeLayout bookmark_view;
            ImageView imgIcon;
            TextView txtTitle;
            TextView txtUrl;
            TextView time;
            ImageView buttonViewOption;
        }
    }


}