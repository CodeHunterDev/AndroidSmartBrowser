package com.android.smartwebview.settings;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.android.smartwebview.R;
import com.android.smartwebview.activity.BrowserActivity;
import com.android.smartwebview.utils.ThemeUtils;

public class SettingsActivity extends AppCompatActivity {

    FrameLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ThemeUtils ut = new ThemeUtils(this);
        ut.setTheme();
        setContentView(R.layout.preference);
        setTitle("Settings");
        layout = findViewById(R.id.layout);
        if(ThemeUtils.isBlack()){
            // m2.getIcon().setColorFilter(new PorterDuffColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN));
            layout.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorBlackTheme));
        }

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.layout, new SettingsFragment())
                .commit();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.abc, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        return super.onOptionsItemSelected(item);
    }

    //@Override
   // public void onBackPressed() {
   //     Intent in = new Intent(this, BrowserActivity.class);
     //   in.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
   //     startActivity(in);
   // }

}