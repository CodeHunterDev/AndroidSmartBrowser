package com.android.smartwebview;

public class Config {

	/*[]Mobile website or web based mobile app URL*/
	public static final String mobile_website_url = "https://try-tolearn.blogspot.com"; /*<<=========Important

	/*[]Mobile WebSearch URL(Search box url)*/
	public static final String WebSearch = "https://www.google.com/search?q="; /*<<=========Important

	/* enable JavaScript for webview*/
	public static boolean javascript = true;

    /*[]App Play Store URL(Play Store URL for share app and RATE your ANDROID App)*/
    public static final String PlayStoreUrl = "https://play.google.com/";

	public static boolean ADMOB         = true;         // to load admob or not
	/*The frequency in which interstitial ads are shown for when loading pages
	 */

	//("0" to never show, '1' to always show, '3' to 1 out of 3, etc)
	public static final int INTERSTITIAL_PAGE_INTERVAL = 3;

	// instead of default browser, open external URLs in Chrome tab
	public static boolean Browser_TAB           = false;

/*[]Number of lunches before Rate me message shows*/
    public static final int number_of_uses_before_launching_the_rate_dialog = 5;

	/*[] Offline Application*/
	public static final Boolean offline_app = false;

	/*[] show progress bar in app*/
	public static boolean SMART_PBAR        = true;

	/*[]To deactivate RateDialog change "yes" to "no"*/
    public static boolean rateActive = true;

	// URL where you process external content shared with the app
	public static String SHARE_URL      = mobile_website_url + "?share=";

    /**
     * ADVANCED SETTINGS
     */

	//All urls that should always be opened outside the WebView and in the browser, download manager, or their respective app
	public static final String[] OPEN_OUTSIDE_WEBVIEW = new String[]{"market://", "play.google.com", "plus.google.com", "mailto:", "tel:", "vid:", "geo:", "whatsapp:", "sms:", "intent://"};

	// open external url with default browser instead of app webview
	public static boolean EXTURL_URL        = false;

	/**
	 * Navigation Drawer Url
	 */

	/*[]Mobile Intro Url or web based Intro URL*/
	public static final String Intro_Url = "file:///android_asset/intro.html"; /*<<=========Important
/*[]Mobile Product URL(web based product Url)*/
	public static final String Product_Url = "file:///android_asset/products.html"; /*<<=========Important
/*[]Mobile Service Url us or Service page Url*/
	public static final String Services_Url = "file:///android_asset/services.html"; /*<<=========Important
/*[]Mobile Help Url or Help page URL*/
	public static final String Help_Url = "file:///android_asset/help.html"; /*<<=========Important
/*[]Mobile Website URL(this Url open in external browser /////OnClick Only////)*/
	public static final String WebSite_Url = "https://www.google.com"; /*<<=========Important
/*[]Mobile Privacy Policy or Privacy Policy page Url*/
	public static final String PrivacyPolicyUrl = "file:///android_asset/privacy_policy.html";
/*[]Mobile About us or About page Url*/
	public static final String aboutUrl = "file:///android_asset/about.html";

}