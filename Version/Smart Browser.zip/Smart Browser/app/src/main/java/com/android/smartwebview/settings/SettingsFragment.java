package com.android.smartwebview.settings;

import android.app.Activity;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import com.android.smartwebview.R;

public class SettingsFragment extends PreferenceFragmentCompat {

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.preferences, rootKey);

        Preference clear_cookies_cache = findPreference("clear_cookies_cache");
        assert clear_cookies_cache != null;
        clear_cookies_cache.setOnPreferenceClickListener(preference -> {
            //((BrowserActivity) requireActivity()).clearBrowsingData();
            return true;
        });

        Preference privacy_policy = findPreference("privacy_policy");
        assert privacy_policy != null;
        privacy_policy.setOnPreferenceClickListener(preference -> {

            final TextView mCreditsTitle = new TextView(getActivity());
            mCreditsTitle.setText(getResources().getString(R.string.privacyPolicy));
            mCreditsTitle.setTypeface(Typeface.DEFAULT_BOLD);
            mCreditsTitle.setTextSize(20);
            mCreditsTitle.setGravity(Gravity.CENTER_HORIZONTAL);

            WebView mWebView = new WebView(getActivity());
            mWebView.loadUrl("file:///android_asset/PrivacyPolicy.txt");
            mWebView.setWebViewClient(new WebViewClient() {
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    return super.shouldOverrideUrlLoading(view, url);
                }
            });

            AlertDialog mCreditsDialog = new AlertDialog.Builder(requireActivity())
                    .setCustomTitle(mCreditsTitle)
                    .setPositiveButton(android.R.string.ok, null)
                    .setView(mWebView)
                    .show();
            return true;
        });

        Preference credits = findPreference("credits");
        assert credits != null;
        credits.setOnPreferenceClickListener(preference -> {
            AlertDialog mCreditsDialog;
            final TextView mCreditsTitle = new TextView(getActivity());
            mCreditsTitle.setText(getResources().getString(R.string.credits));
            mCreditsTitle.setTypeface(Typeface.DEFAULT_BOLD);
            mCreditsTitle.setTextSize(20);
            mCreditsTitle.setGravity(Gravity.CENTER_HORIZONTAL);

            WebView mWebView = new WebView(getActivity());
            mWebView.loadUrl("file:///android_asset/about.html");
            mWebView.setWebViewClient(new WebViewClient() {
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    return super.shouldOverrideUrlLoading(view, url);
                }
            });

            mCreditsDialog = new AlertDialog.Builder(requireActivity())
                    .setCustomTitle(mCreditsTitle)
                    .setPositiveButton(android.R.string.ok, null)
                    .setView(mWebView)
                    .show();
            return true;
        });


        Preference Clear_Cookies_Cache = findPreference("clear_cookies_cache");
        assert Clear_Cookies_Cache != null;
        Clear_Cookies_Cache.setOnPreferenceClickListener(preference -> {
            final TextView mCreditsTitle = new TextView(getActivity());
            mCreditsTitle.setText("");
            mCreditsTitle.setTypeface(Typeface.DEFAULT_BOLD);
            mCreditsTitle.setTextSize(20);
            mCreditsTitle.setGravity(Gravity.CENTER_HORIZONTAL);

            AlertDialog mCreditsDialog = new AlertDialog.Builder(requireActivity())
                    .setTitle("Clear Cookies Cache")
                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    })
                    .setNegativeButton(android.R.string.cancel, null)
                    .setView(mCreditsTitle)
                    .show();
            return true;
        });


    }

}