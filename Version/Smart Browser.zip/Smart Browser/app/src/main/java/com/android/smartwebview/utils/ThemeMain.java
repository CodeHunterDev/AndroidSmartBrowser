package com.android.smartwebview.utils;

import android.content.Context;
import com.android.smartwebview.R;

public class ThemeMain {

    private Context mContext;
    public ThemeMain(Context context){
        mContext = context;
    }
    private static boolean isBlackTheme = false;
    public  void setTheme() {
        PreferenceUtils utils = new PreferenceUtils(mContext);
        switch (utils.getTheme()) {
            case 1:
                mContext.setTheme(R.style.AppTheme);
                isBlackTheme = false;
                break;
            case 2:
                mContext.setTheme(R.style.AppThemeBlack);
                isBlackTheme = true;
                break;
        }
    }
    public static boolean isBlack(){
        return  isBlackTheme;
    }

}