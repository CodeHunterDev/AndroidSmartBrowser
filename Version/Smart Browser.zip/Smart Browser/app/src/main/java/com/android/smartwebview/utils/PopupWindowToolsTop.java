package com.android.smartwebview.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;

import com.android.smartwebview.R;

/**
 * Created by Young on 2016/11/28.
 */

public class PopupWindowToolsTop extends PopupWindow {
    private View toolsTabView;

    @SuppressLint("InflateParams")
    public PopupWindowToolsTop(Context context) {
        super(context);
        LayoutInflater toolsTabInflater = LayoutInflater.from(context);
        this.toolsTabView = toolsTabInflater.inflate(R.layout.pop_window_tools_top, null);
        setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        setContentView(toolsTabView);
        setOutsideTouchable(true);
        setFocusable(true);
    }

    public View getView(int id) {
        return this.toolsTabView.findViewById(id);
    }
}
