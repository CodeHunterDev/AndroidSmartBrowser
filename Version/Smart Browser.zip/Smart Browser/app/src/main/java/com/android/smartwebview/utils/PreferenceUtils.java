package com.android.smartwebview.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class PreferenceUtils {

     @SuppressLint("StaticFieldLeak")
     private static Context mContext;
    private SharedPreferences prefs;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

   public PreferenceUtils(Context context){
   mContext = context;
    }

    public  boolean getJavaEnabled(){
        prefs = PreferenceManager.getDefaultSharedPreferences(mContext);
    return prefs.getBoolean("SP_JAVASCRIPT", true);
    }

    public  boolean getEnableCookies(){
        prefs = PreferenceManager.getDefaultSharedPreferences(mContext);
        return prefs.getBoolean("SP_enable_cookies", true);
    }

    public  int getSearchEngine(){
        String setSearchEngine;
        prefs = PreferenceManager.getDefaultSharedPreferences(mContext);
        setSearchEngine = prefs.getString("search","1");
        return Integer.parseInt(setSearchEngine);
    }

    public  int getTheme(){
        try {
            String color;
            prefs = PreferenceManager.getDefaultSharedPreferences(mContext);
            color = prefs.getString("color", "1");
            return Integer.parseInt(color);
        }
        catch (Exception e){
            return 1;
        }
    }





    public void setJavaEnabled(boolean enabled){
        editor = sharedPreferences.edit();
        editor.putBoolean("SP_JAVASCRIPT",enabled);
        editor.apply();
    }

    public void setEnableCookies(boolean enabled){
        editor = sharedPreferences.edit();
        editor.putBoolean("SP_enable_cookies",enabled);
        editor.apply();
    }

    public void setSearchEngine(String setSearchEngine){
        editor = sharedPreferences.edit();
        editor.putString("search",setSearchEngine);
        editor.apply();
    }

}
