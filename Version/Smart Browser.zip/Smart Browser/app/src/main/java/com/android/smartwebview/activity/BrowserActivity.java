package com.android.smartwebview.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.pm.ShortcutInfoCompat;
import androidx.core.content.pm.ShortcutManagerCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.graphics.drawable.IconCompat;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.net.http.SslCertificate;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebBackForwardList;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import com.android.smartwebview.Config;
import com.android.smartwebview.R;
import com.android.smartwebview.history_book.Contact;
import com.android.smartwebview.history_book.HistoryActivity;
import com.android.smartwebview.history_book.History_helper;
import com.android.smartwebview.history_book.bookmark.BookMark_helper;
import com.android.smartwebview.history_book.bookmark.BookmarkActivity;
import com.android.smartwebview.settings.SettingsActivity;
import com.android.smartwebview.tabManager.Tab;
import com.android.smartwebview.utils.AdBlocking;
import com.android.smartwebview.utils.PopupWindowTools;
import com.android.smartwebview.utils.PopupWindowToolsTop;
import com.android.smartwebview.utils.PreferenceUtils;
import com.android.smartwebview.utils.ThemeMain;
import com.android.smartwebview.view.AdvancedWebView;
import com.android.smartwebview.view.ObservableWebView;
import com.android.smartwebview.view.SmartChromeClient;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.iid.FirebaseInstanceId;

import java.io.ByteArrayOutputStream;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BrowserActivity extends AppCompatActivity implements AdvancedWebView.Listener, View.OnClickListener {


    AdvancedWebView webview;
    public int currentTabIndex;
    private FrameLayout webviews;
    public TextView txtTabCount;
    int asw_error_counter = 0;
    private SecureRandom random = new SecureRandom();
    protected ProgressBar mProgressBar;
    public SmartChromeClient chromeClient;
    public AppCompatActivity mActivity;
    private final static int file_perm = 2;
    RelativeLayout mListViewLayout;
    RelativeLayout web_tool_lt;
    public RecyclerView mVideoRecyclerView;
    private YT_recycler_adapter mVideoAdapter;


    private ImageButton webViewControlButton;
    private ImageButton webViewControlButton2;
    private TextInputEditText searchTextInput;
    AppCompatImageButton voice;
    private ImageButton clearSearchTextButton;
    private ImageButton menuButton;

    private History_helper dbManager;
    BookMark_helper Bookmark_Manager;
    AppCompatImageButton add_new_page;

    ImageButton reload;
    ImageButton go_forward;
    ImageButton home_button;

    private EditText searchEdit;
    private TextView searchCount;

    private SharedPreferences prefs;
    FrameLayout Mask;
    private int searchEngine = 1;

    public Context mContext;
    private ImageView tools;
    //tools popup window
    private PopupWindowTools toolsPopWindow;
    PopupWindowToolsTop toolsPopWindowTop;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public static String fcm_channel = "1";
    public String fcm_token;
    public static int FCM_ID = fcm_id();

    private String snackbarText;
    private String shortcutTitle;
    private IconCompat shortcutIcon;
    private boolean isAdBlockingEnabled;

    //set request code
    public static final int REQUEST_DEFAULT = -1;
    public static final int REQUEST_OPEN_FAV = 0;
    public static final int REQUEST_OPEN_HIS = 0;

    private static final String startPage = "file:///android_asset/homepage/index.html";

    public static String SMART_HOST			= aswm_host(Config.mobile_website_url);

    Boolean true_online = !Config.offline_app;
    static class TitleAndUrl {
        String title;
        String url;
    }

    private ArrayList<TitleAndUrl> closedTabs = new ArrayList<>();

    public Tab getCurrentTab() {
        return Tab.tabs.get(currentTabIndex);
    }

    private AdvancedWebView getCurrentWebView() {
        return getCurrentTab().webview;
    }

    private String mobileUserAgent;
    private String desktopUserAgent;
    private boolean isDesktopMode = false;
    private static final String DESKTOP_DEVICE = "X11; Linux x86_64";
    private static final String DESKTOP_USER_AGENT_FALLBACK = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36";
    private static final String PATTERN_USER_AGENT = "([^)]+ \\()([^)]+)(\\) .*)";
    @SuppressWarnings("unused")
    private static final String TAG = BrowserActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ThemeMain mTheme = new ThemeMain(this);
        mTheme.setTheme();
        setContentView(R.layout.browser_main);

        webviews = findViewById(R.id.webviews);
        tools = findViewById(R.id.tools_button);
        mListViewLayout = findViewById(R.id.mListViewLayout);
        searchTextInput = findViewById(R.id.searchTextInput);
        voice = findViewById(R.id.voice);

        webViewControlButton = findViewById(R.id.webViewControlButton);
        webViewControlButton2 = findViewById(R.id.webViewControlButton2);
        clearSearchTextButton = findViewById(R.id.clearSearchTextButton);
        menuButton = findViewById(R.id.menuButton);
        txtTabCount = findViewById(R.id.number_tab);
        add_new_page = findViewById(R.id.add_new_page);
        AppCompatImageButton tab_back = findViewById(R.id.tab_back);
        AppCompatImageButton undo_Tabs = findViewById(R.id.undo_Tabs);
        web_tool_lt = findViewById(R.id.web_tool_lt);
        reload = findViewById(R.id.reload);
        go_forward = findViewById(R.id.go_forward);
        home_button = findViewById(R.id.home_button);
        Mask = findViewById(R.id.Mask);

        currentTabIndex = 0;
        // requesting new FCM token; updating final cookie variable
        fcm_token();

        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        onNightModeChange();

        PreferenceUtils utils = new PreferenceUtils(this);
        searchEngine = utils.getSearchEngine();

        // Handle intents
        Intent intent = getIntent();
        Uri uri = intent.getData();
        String url;
        url = (uri != null ? uri.toString() : startPage);
        // Load either the start page or the URL provided by an intent
        newTab(url);
        getCurrentWebView().setVisibility(View.VISIBLE);
        getCurrentWebView().requestFocus();

        dbManager = new History_helper(this);
        Bookmark_Manager = new BookMark_helper(this);

        bookmark();

        //tools popup window
        toolsPopWindow = new PopupWindowTools(this);
        //tools popup window Top
        toolsPopWindowTop = new PopupWindowToolsTop(this);

        // notification manager
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if(Build.VERSION.SDK_INT >= 26) {
            NotificationChannel notificationChannel = new NotificationChannel(fcm_channel,String.valueOf(R.string.notification_channel_name), NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.setDescription(String.valueOf(R.string.notification_channel_desc));
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setShowBadge(true);
            assert notificationManager != null;
            notificationManager.createNotificationChannel(notificationChannel);
            notificationManager.createNotificationChannel(notificationChannel);
        }

        // Handle focus changes of the search field
        searchTextInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (view.isFocused()) {
                    voice.setVisibility(View.GONE);
                    webViewControlButton.setVisibility(View.GONE);
                    webViewControlButton2.setVisibility(View.GONE);
                    clearSearchTextButton.setVisibility(View.VISIBLE);
                    menuButton.setVisibility(View.GONE);
                } else {
                    voice.setVisibility(View.VISIBLE);
                    clearSearchTextButton.setVisibility(View.GONE);
                    menuButton.setVisibility(View.VISIBLE);
                    WebViewControl();
                    searchTextInput.setText(getCurrentWebView().getUrl());
                }
            }
        });

        // Handle the "go button" shown in the keyboard
        searchTextInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                searchTextInput.setCursorVisible(true);
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    if (Objects.requireNonNull(searchTextInput.getText()).toString().isEmpty()) {
                        searchTextInput.setText(getCurrentWebView().getUrl());
                    } else {
                        String toSearch;
                        toSearch = searchTextInput.getText().toString();
                        if (toSearch.contains("http://") || toSearch.contains("https://")) {
                            aswm_view(toSearch, false, asw_error_counter, getCurrentWebView());
                        } else {
                            if (toSearch.contains("www")) {
                                aswm_view("http://" + toSearch, false, asw_error_counter, getCurrentWebView());
                            } else {
                                if (toSearch.contains(".")) {
                                    aswm_view("http://" + toSearch, false, asw_error_counter, getCurrentWebView());
                                } else {
                                    searchWeb(toSearch, getCurrentWebView());
                                }
                            }
                        }
                    }

                    searchTextInput.clearFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    Objects.requireNonNull(imm).toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                    return true;
                }
                return false;

            }
        });

        getCurrentWebView().setOnScrollChangeListener(getCurrentWebView(), new ObservableWebView() {
            @Override
            public void onHide() {
                slideDown(web_tool_lt);
            }

            @Override
            public void onShow() {
                slideUp(web_tool_lt);
            }
        });
        //ButtonClickedListener
        ButtonClickedListener buttonClickedListener = new ButtonClickedListener();
        txtTabCount.setOnClickListener(buttonClickedListener);
        add_new_page.setOnClickListener(buttonClickedListener);
        tab_back.setOnClickListener(buttonClickedListener);
        tab_back.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorBlackTheme));
        undo_Tabs.setOnClickListener(buttonClickedListener);
        webViewControlButton.setOnClickListener(buttonClickedListener);
        reload.setOnClickListener(buttonClickedListener);
        go_forward.setOnClickListener(buttonClickedListener);
        home_button.setOnClickListener(buttonClickedListener);
        webViewControlButton2.setOnClickListener(buttonClickedListener);
        clearSearchTextButton.setOnClickListener(buttonClickedListener);
        menuButton.setOnClickListener(buttonClickedListener);
        tools.setOnClickListener(buttonClickedListener);


        searchEdit = findViewById(R.id.searchEdit);
        searchEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                getCurrentWebView().findAllAsync(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
        searchCount = findViewById(R.id.searchCount);
        findViewById(R.id.searchFindNext).setOnClickListener(v -> {
            hideKeyboard();
            getCurrentWebView().findNext(true);
        });
        findViewById(R.id.searchFindPrev).setOnClickListener(v -> {
            hideKeyboard();
            getCurrentWebView().findNext(false);
        });
        findViewById(R.id.searchClose).setOnClickListener(v -> {
            getCurrentWebView().clearMatches();
            searchEdit.setText("");
            getCurrentWebView().requestFocus();
            findViewById(R.id.searchPane).setVisibility(View.GONE);
            hideKeyboard();
        });

    }

    private class ButtonClickedListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            if (view.getId() == R.id.number_tab) {
                showOpenTabs();
                mListViewLayout.setVisibility(View.VISIBLE);
            } else if(view.getId() == R.id.add_new_page) {
                newTab(startPage);
                switchToTab(Tab.tabs.size() - 1);
                mListViewLayout.setVisibility(View.GONE);
            } else if(view.getId() == R.id.tab_back) {
                mListViewLayout.setVisibility(View.GONE);
            } else if(view.getId() == R.id.undo_Tabs) {
                UndoTabs();
            } else if(view.getId() == R.id.webViewControlButton) {
                // Handle "WebView control button" in the search field
                pageInfo();
            } else if(view.getId() == R.id.reload) {
                if (getCurrentWebView().getProgress() == 100) {
                    getCurrentWebView().reload();
                } else {
                    getCurrentWebView().stopLoading();
                }
            } else if(view.getId() == R.id.go_forward) {
                if (getCurrentWebView().canGoForward()) {
                        getCurrentWebView().goForward();

                }
            } else if(view.getId() == R.id.home_button) {
                aswm_view(startPage, false, asw_error_counter, getCurrentWebView());
            } else if(view.getId() == R.id.webViewControlButton2) {
                // Handle "WebView control button" in the search field
                pageInfo();
            } else if(view.getId() == R.id.clearSearchTextButton) {
                // Handle "clear search text button" in the search field
                Objects.requireNonNull(searchTextInput.getText()).clear();
            } else if(view.getId() == R.id.menuButton) {
                // Handle "menu button" in bottom bar
                PopupWindowTop();
            } else if(view.getId() == R.id.tools_button) {
                LayoutInflater toolsInflater = LayoutInflater.from(getApplicationContext());
                @SuppressLint("InflateParams") View toolsView = toolsInflater.inflate(R.layout.pop_window_tools, null);
                toolsPopWindow.showAtLocation(toolsView, Gravity.BOTTOM | Gravity.END, 0, tools.getHeight());

                LinearLayout night_mode = (LinearLayout) toolsPopWindow.getView(R.id.night_mode);
                night_mode.setOnClickListener(BrowserActivity.this);
            }
        }
    }




    @SuppressLint("DefaultLocale")
    private AdvancedWebView createWebView() {

        webview = new AdvancedWebView(this);
        webview.setListener(this, this);
        webview.setGeolocationEnabled(false);
        webview.setMixedContentAllowed(true);
        webview.setCookiesEnabled(true);
        webview.setThirdPartyCookiesEnabled(true);

        WebSettings settings = webview.getSettings();
        initUserAgent(settings);
        enableDesktopMode(webview, isDesktopMode);

        mProgressBar = findViewById(R.id.mProgressBar);

        // Initialize ad blocking
        AdBlocking.init(this);
        sharedPreferences = getPreferences(Context.MODE_PRIVATE);
        isAdBlockingEnabled = sharedPreferences.getBoolean("ad_blocking", true);

        webview.setWebViewClient(new WebViewClient() {

            // Ad blocking feature
            private final Map<String, Boolean> loadedUrls = new HashMap<>();

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                boolean ad;
                String url = request.getUrl().toString();
                if (isAdBlockingEnabled) {
                    if (!loadedUrls.containsKey(url)) {
                        ad = AdBlocking.isAd(url);
                        loadedUrls.put(url, ad);
                    } else {
                        ad = loadedUrls.get(url);
                    }
                    return (ad ? AdBlocking.createEmptyResource() : super.shouldInterceptRequest(view, request));
                }
                return super.shouldInterceptRequest(view, request);
            }

            public boolean shouldOverrideUrlLoading(AdvancedWebView view, String url) {
                if (url.startsWith("fcm:")) {
                    String fcm = startPage+"?fcm="+fcm_token();
                    aswm_view(fcm,false, asw_error_counter, view);
                    Log.d("OFFLINE_FCM_TOKEN",fcm);
                    return true;
                    // opening external URLs in android default web browser
                } else if (Config.EXTURL_URL && !aswm_host(url).equals(SMART_HOST)) {
                    aswm_view(url,true, asw_error_counter, view);

                    // else return false for no special action
                }
                // Return true to override url loading (In this case do
                // nothing).
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                mProgressBar.setVisibility(View.VISIBLE);
                searchTextInput.setText(url);

                if (searchTextInput.hasFocus()) {
                    searchTextInput.clearFocus();
                }
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                mProgressBar.setVisibility(View.GONE);
                searchTextInput.setText(url);
                WebViewControl();

                final String title = getCurrentWebView().getTitle();
                // get image from imageView layout
                //Bitmap image = imageView2Bitmap(tools);

                //OR get image from Drawable
                Bitmap image = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);

                // convert bitmap to byte
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                image.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] imageInByte = stream.toByteArray();
                // Inserting Contacts
                Log.d("Insert: ", "Inserting ..");

                if (dbManager.checkUrl(url, History_helper.TABLE_NAME)) {
                    dbManager.deleteURL(url, History_helper.TABLE_NAME);
                    dbManager.addContact(new Contact(title, url, System.currentTimeMillis(), imageInByte));
                } else {
                    dbManager.addContact(new Contact(title, url, System.currentTimeMillis(), imageInByte));
                }

            }
        });

        chromeClient = new SmartChromeClient(mActivity, webview, mProgressBar);
        webview.setWebChromeClient(chromeClient);

        webview.setFindListener((activeMatchOrdinal, numberOfMatches, isDoneCounting) ->
                searchCount.setText(numberOfMatches == 0 ? "Not found" :
                        String.format("%d / %d", activeMatchOrdinal + 1, numberOfMatches)));

        return webview;
    }

    // get image from imageView layout
    //private Bitmap imageView2Bitmap(ImageView view){
    //    return ((BitmapDrawable)view.getDrawable()).getBitmap();
    //  }

    void searchWeb(String query, AdvancedWebView webview) {
        switch (searchEngine) {
            case 1:
                String google = "https://www.google.com/search?q=" + query.replace(" ", "+");
                webview.loadUrl(google);
                break;
            case 2:
                String bing = "http://www.bing.com/search?q=" + query.replace(" ","+");
                webview.loadUrl(bing);
                break;
            case 3:
                String yahoo = "https://search.yahoo.com/search?p=" + query.replace(" ","+");
                webview.loadUrl(yahoo);
                break;
            case 4:
                String duck = "https://duckduckgo.com/?q=" + query.replace(" ","+");
                webview.loadUrl(duck);
                break;
            case 5:
                String ask = "http://www.ask.com/web?q=" + query.replace(" ","+");
                webview.loadUrl(ask);
                break;
            case 6:
                String wow = "http://www.wow.com/search?s_it=search-thp&v_t=na&q=" + query.replace(" ","+");
                webview.loadUrl(wow);
                break;
            case 7:
                String aol = "https://search.aol.com/aol/search?s_chn=prt_ticker-test-g&q=" + query.replace(" ","+");
                webview.loadUrl(aol);
                break;
            case 8:
                String crawler = "https://www.webcrawler.com/serp?q=" + query.replace(" ","+");
                webview.loadUrl(crawler);
                break;
            case 9:
                String myweb = "http://int.search.mywebsearch.com/mywebsearch/GGmain.jhtml?searchfor=" +  query.replace(" ","+");
                webview.loadUrl(myweb);
                break;
            case 10:
                String info = "http://search.infospace.com/search/web?q=" + query.replace(" ","+");
                webview.loadUrl(info);
                break;
            case 11:
                String yandex = "https://www.yandex.com/search/?text=" + query.replace(" ","+");
                webview.loadUrl(yandex);
                break;
            case 12:
                String startpage = "https://www.startpage.com/do/search?q="  + query.replace(" ","+");
                webview.loadUrl(startpage);
                break;
            case 13:
                String searx = "https://searx.me/?q="  + query.replace(" ","+");
                webview.loadUrl(searx);
                break;
        }
    }

    @SuppressLint("NewApi")
    @Override
    protected void onResume() {
        super.onResume();
        webview.onResume();
        // ...
        //Coloring the "recent apps" tab header; doing it onResume, as an insurance
        if (Build.VERSION.SDK_INT >= 23) {
            Bitmap bm = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
            ActivityManager.TaskDescription taskDesc;
            taskDesc = new ActivityManager.TaskDescription(getString(R.string.app_name), bm, getColor(R.color.colorPrimary));
            BrowserActivity.this.setTaskDescription(taskDesc);
        }
    }

    @SuppressLint("NewApi")
    @Override
    protected void onPause() {
        webview.onPause();
        // ...
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        webview.onDestroy();
        // ...
        super.onDestroy();
    }

    @Override
    public void onPageError(int errorCode, String description, String failingUrl) {
    }

    public void WebViewControl() {

        SslCertificate certificate = getCurrentWebView().getCertificate();
        if (certificate == null) {
            webViewControlButton2.setVisibility(View.VISIBLE);
            webViewControlButton.setVisibility(View.GONE);
        } else {
            webViewControlButton2.setVisibility(View.GONE);
            webViewControlButton.setVisibility(View.VISIBLE);
        }

    }

    @SuppressLint("NewApi")
    @Override
    public void onDownloadRequested(String url, String suggestedFilename, String mimeType, long contentLength, String contentDisposition, String userAgent) {

        if (!check_permission(2)) {
            ActivityCompat.requestPermissions(BrowserActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, file_perm);
        } else {

            if (AdvancedWebView.handleDownload(this, url, suggestedFilename)) {
                // download successfully handled
                Toast.makeText(getApplicationContext(), getString(R.string.dl_downloading2), Toast.LENGTH_LONG).show();

            } else {
                // download couldn't be handled because user has disabled download manager app on the device
                Toast.makeText(getApplicationContext(), getString(R.string.went_wrong), Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Opening URLs inside webview with request
    void aswm_view(String url, Boolean tab, int error_counter, AdvancedWebView webview) {
        if(error_counter > 2){
            asw_error_counter = 0;
            smart_exit();
        }else {
            if(tab){
                if(Config.Browser_TAB) {
                    CustomTabsIntent.Builder intentBuilder = new CustomTabsIntent.Builder();
                    intentBuilder.setToolbarColor(ContextCompat.getColor(this, R.color.colorPrimary));
                    intentBuilder.setSecondaryToolbarColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
                    intentBuilder.setStartAnimations(this, android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                    intentBuilder.setExitAnimations(this, android.R.anim.slide_in_left, android.R.anim.slide_out_right);
                    CustomTabsIntent customTabsIntent = intentBuilder.build();
                    try {
                        customTabsIntent.launchUrl(BrowserActivity.this, Uri.parse(url));
                    } catch (ActivityNotFoundException e) {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(url));
                        startActivity(intent);
                    }
                }else{
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(url));
                    startActivity(intent);
                }
            } else {

                webview.loadUrl(url);
            }
        }
    }


    private void toggleNightMode() {
        if (ThemeMain.isBlack()) {
            Mask.setVisibility(View.GONE);
            prefs.edit().putString("color", "1").apply();
            ThemeMain mTheme = new ThemeMain(this);
            mTheme.setTheme();
            BrowserActivity.this.recreate();
        } else {
            Mask.setVisibility(View.VISIBLE);
            prefs.edit().putString("color", "2").apply();
            ThemeMain mTheme = new ThemeMain(this);
            mTheme.setTheme();
            BrowserActivity.this.recreate();
        }
    }

    private void onNightModeChange() {
        if (ThemeMain.isBlack()) {
            Mask.setVisibility(View.VISIBLE);
        } else {
            Mask.setVisibility(View.GONE);
        }
    }

    //Getting host name
    public static String aswm_host(String url){
        if (url == null || url.length() == 0) {
            return "";
        }
        int dslash = url.indexOf("//");
        if (dslash == -1) {
            dslash = 0;
        } else {
            dslash += 2;
        }
        int end = url.indexOf('/', dslash);
        end = end >= 0 ? end : url.length();
        int port = url.indexOf(':', dslash);
        end = (port > 0 && port < end) ? port : end;
        Log.w("URL Host: ",url.substring(dslash, end));
        return url.substring(dslash, end);
    }

    public static int fcm_id(){
        //Date now = new Date();
        //Integer.parseInt(new SimpleDateFormat("ddHHmmss",  Locale.US).format(now));
        return 1;
    }

    public String fcm_token(){
        FirebaseInstanceId.getInstance().getInstanceId().addOnSuccessListener( BrowserActivity.this, instanceIdResult -> {
            fcm_token = instanceIdResult.getToken();
            if(true_online) {
                CookieManager cookieManager = CookieManager.getInstance();
                cookieManager.setAcceptCookie(true);
                cookieManager.setCookie(Config.mobile_website_url, "FCM_TOKEN="+fcm_token);
                Log.d("FCM_BAKED","YES");
                //Log.d("COOKIES: ", cookieManager.getCookie(ASWV_URL));
            }
            Log.d("REQ_FCM_TOKEN", fcm_token);
        }).addOnFailureListener(e -> Log.d("REQ_FCM_TOKEN", "FAILED"));
        return fcm_token;
    }

    private void newTab(String url) {
        AdvancedWebView webview = createWebView();
        webview.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        webview.setVisibility(View.GONE);
        Tab tab = new Tab(webview);
        Tab.tabs.add(tab);
        webviews.addView(webview);
        setTabCountText(Tab.tabs.size());
        aswm_view(url, false, asw_error_counter, webview);
    }

    private void switchToTab(int tab) {
        getCurrentWebView().setVisibility(View.GONE);
        currentTabIndex = tab;
        getCurrentWebView().setVisibility(View.VISIBLE);
        searchTextInput.setText(getCurrentWebView().getUrl());
        getCurrentWebView().requestFocus();
    }


    private void closeCurrentTab() {
        if (getCurrentWebView().getUrl() != null && !getCurrentWebView().getUrl().equals(startPage)) {
            TitleAndUrl titleAndUrl = new TitleAndUrl();
            titleAndUrl.title = getCurrentWebView().getTitle();
            titleAndUrl.url = getCurrentWebView().getUrl();
            closedTabs.add(0, titleAndUrl);
        }
        ((FrameLayout) findViewById(R.id.webviews)).removeView(getCurrentWebView());
        getCurrentWebView().destroy();
        Tab.tabs.remove(currentTabIndex);
        if (currentTabIndex >= Tab.tabs.size()) {
            currentTabIndex = Tab.tabs.size() - 1;
        }
        if (currentTabIndex == -1) {
            // We just closed the last tab
            newTab(startPage);
            currentTabIndex = 0;
        }
        getCurrentWebView().setVisibility(View.VISIBLE);
        searchTextInput.setText(getCurrentWebView().getUrl());
        setTabCountText(Tab.tabs.size());
        getCurrentWebView().requestFocus();
    }


    private void setTabCountText(int count) {
        if (txtTabCount != null) {
            txtTabCount.setText(String.valueOf(count));
        }
    }

    private void pageInfo() {
        String s = "URL: " + getCurrentWebView().getUrl() + "\n";
        s += "Title: " + getCurrentWebView().getTitle() + "\n\n";
        SslCertificate certificate = getCurrentWebView().getCertificate();
        s += certificate == null ? "Not secure" : "Certificate:  Secure\n" + certificateToStr(certificate);

        new AlertDialog.Builder(this)
                .setTitle("Page info")
                .setMessage(s)
                .setPositiveButton("OK", (dialog, which) -> {})
                .show();
    }


    @SuppressLint("DefaultLocale")
    private static String certificateToStr(SslCertificate certificate) {
        if (certificate == null) {
            return null;
        }
        String s = "";
        SslCertificate.DName issuedTo = certificate.getIssuedTo();
        if (issuedTo != null) {
            s += "Issued to: " + issuedTo.getDName() + "\n";
        }
        SslCertificate.DName issuedBy = certificate.getIssuedBy();
        if (issuedBy != null) {
            s += "Issued by: " + issuedBy.getDName() + "\n";
        }
        Date issueDate = certificate.getValidNotBeforeDate();
        if (issueDate != null) {
            s += String.format("Issued on: %tF %tT %tz\n", issueDate, issueDate, issueDate);
        }
        Date expiryDate = certificate.getValidNotAfterDate();
        if (expiryDate != null) {
            s += String.format("Expires on: %tF %tT %tz\n", expiryDate, expiryDate, expiryDate);
        }
        return s;
    }

    private void showOpenTabs() {
        mVideoRecyclerView = findViewById(R.id.yt_recycler_view);

        LinearLayoutManager HorizontalLayout;

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        mVideoRecyclerView.setLayoutManager(layoutManager);

        mVideoAdapter = new YT_recycler_adapter(Tab.tabs, getApplicationContext());

        HorizontalLayout = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        mVideoRecyclerView.setLayoutManager(HorizontalLayout);

        mVideoRecyclerView.setAdapter(mVideoAdapter);

        mVideoAdapter.notifyDataSetChanged();

        mVideoRecyclerView.scrollToPosition(currentTabIndex);

    }

    private void UndoTabs(){

        if (!closedTabs.isEmpty()) {
            String[] items1 = new String[closedTabs.size()];
            for (int i = 0; i < closedTabs.size(); i++) {
                items1[i] = closedTabs.get(i).title;
            }
            AlertDialog.Builder tabsDialog = new AlertDialog.Builder(BrowserActivity.this)
                    .setTitle("Undo closed tabs")
                    .setItems(items1, (dialog1, which) -> {
                        String url = closedTabs.get(which).url;
                        closedTabs.remove(which);
                        newTab(url);
                        switchToTab(Tab.tabs.size() - 1);
                    });
            tabsDialog.show();
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.UndoTabs), Toast.LENGTH_SHORT).show();
        }

    }

    private void showTabHistory() {
        WebBackForwardList list = getCurrentWebView().copyBackForwardList();
        final int size = list.getSize();
        final int idx = size - list.getCurrentIndex() - 1;
        String[] items = new String[size];
        for (int i = 0; i < size; i++) {
            items[size - i - 1] = list.getItemAtIndex(i).getTitle();
        }
        ArrayAdapter<String> adapter = new ArrayAdapterWithCurrentItem<>(
                this,
                android.R.layout.simple_list_item_1,
                items,
                idx);
        new AlertDialog.Builder(this)
                .setTitle("Navigation History")
                .setAdapter(adapter, (dialog, which) -> getCurrentWebView().goBackOrForward(idx - which))
                .show();
    }

    static class ArrayAdapterWithCurrentItem<T> extends ArrayAdapter<T> {
        int currentIndex;

        ArrayAdapterWithCurrentItem(@NonNull Context context, int resource, @NonNull T[] objects, int currentIndex) {
            super(context, resource, objects);
            this.currentIndex = currentIndex;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            View view = super.getView(position, convertView, parent);
            TextView textView = view.findViewById(android.R.id.text1);
            int icon = position == currentIndex ? android.R.drawable.ic_menu_mylocation : R.drawable.empty;
            Drawable d = getContext().getResources().getDrawable(icon, null);
            int size = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 24, getContext().getResources().getDisplayMetrics());
            d.setBounds(0, 0, size, size);
            textView.setCompoundDrawablesRelative(d, null, null, null);
            textView.setCompoundDrawablePadding(
                    (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 12, getContext().getResources().getDisplayMetrics()));
            return view;
        }
    }


    public class YT_recycler_adapter extends RecyclerView.Adapter<YT_recycler_adapter.MyViewHolder> {

        private ArrayList<Tab> videoList;
        Context context;
        Context mContext;

        private class MyViewHolder extends RecyclerView.ViewHolder {

            private TextView name;
            private ImageView deleteAction;
            private ImageView faviconTab;

            private MyViewHolder(View view) {
                super(view);

                name = view.findViewById(R.id.textTab);
                deleteAction = view.findViewById(R.id.deleteAction);
                faviconTab = view.findViewById(R.id.faviconTab);

            }
        }
        private YT_recycler_adapter(ArrayList<Tab> videoList, Context context) {
            this.context  = context;
            this.videoList = videoList;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.tabs_listview, parent, false);


            return new MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final MyViewHolder holder, final int position) {
            final Tab video = videoList.get(position);
            holder.name.setText(video.webview.getTitle());

            int dimen144dp = getResources().getDimensionPixelSize(R.dimen.layout_width_144dp);
            int dimen108dp = getResources().getDimensionPixelSize(R.dimen.layout_height_108dp);

            float width = getResources().getDimensionPixelSize(R.dimen.layout_width_144dp);
            float height = getResources().getDimensionPixelSize(R.dimen.layout_height_108dp);

            video.webview.setLayerType(View.LAYER_TYPE_HARDWARE, null);

            final Bitmap sBitmap = Bitmap.createBitmap(dimen144dp, dimen108dp, Bitmap.Config.RGB_565);

            Canvas sCanvas = new Canvas(sBitmap);

            int left = video.webview.getLeft();
            int top = video.webview.getTop();
            int status = sCanvas.save();
            sCanvas.translate(-left, -top);

            float scale = width / video.webview.getWidth();
            float scale2 = height / video.webview.getHeight();
            sCanvas.scale(scale, scale, scale2, scale2);

            video.webview.draw(sCanvas);
            sCanvas.restoreToCount(status);

            Paint alphaPaint = new Paint();
            alphaPaint.setColor(Color.TRANSPARENT);

            sCanvas.drawRect(0f, 0f, 1f, height, alphaPaint);
            sCanvas.drawRect(width - 1f, 0f, width, height, alphaPaint);
            sCanvas.drawRect(0f, 0f, width, 1f, alphaPaint);
            sCanvas.drawRect(0f, height - 1f, width, height, alphaPaint);
            sCanvas.setBitmap(null);

            holder.faviconTab.setImageBitmap(sBitmap);

            // get image from imageView layout
            //Bitmap image = imageView2Bitmap(tools);
            //byte[] imageInByte = stream.toByteArray();

            //setting on click listener for each video_item to launch clicked video in new activity
            holder.faviconTab.setOnClickListener(new View.OnClickListener() {
                //onClick method called when the view is clicked
                @Override
                public void onClick(View view) {
                    switchToTab(position);
                    mListViewLayout.setVisibility(View.GONE);

                }
            });

            holder.deleteAction.setOnClickListener(new View.OnClickListener() {
                //onClick method called when the view is clicked
                @Override
                public void onClick(View view) {
                    switchToTab(position);
                    if (getCurrentWebView().getUrl() != null && !getCurrentWebView().getUrl().equals(startPage)) {
                        TitleAndUrl titleAndUrl = new TitleAndUrl();
                        titleAndUrl.title = getCurrentWebView().getTitle();
                        titleAndUrl.url = getCurrentWebView().getUrl();
                        closedTabs.add(0, titleAndUrl);
                    }
                    ((FrameLayout) findViewById(R.id.webviews)).removeView(getCurrentWebView());
                    getCurrentWebView().destroy();
                    Tab.tabs.remove(currentTabIndex);
                    if (currentTabIndex >= Tab.tabs.size()) {
                        currentTabIndex = Tab.tabs.size() - 1;
                    }
                    if (currentTabIndex == -1) {
                        // We just closed the last tab
                        newTab(startPage);
                        currentTabIndex = 0;
                    }
                    getCurrentWebView().setVisibility(View.VISIBLE);
                    searchTextInput.setText(getCurrentWebView().getUrl());
                    setTabCountText(Tab.tabs.size());
                    getCurrentWebView().requestFocus();
                    mVideoAdapter.notifyDataSetChanged();

                }
            });

        }
        @Override
        public int getItemCount() {
            return videoList.size();
        }

    }

    public void smart_exit(){
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    //Checking if particular permission is given or not
    public boolean check_permission(int permission){
        switch(permission){
            case 1:
                return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;

            case 2:
                return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;

            case 3:
                return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;

        }
        return false;
    }

    private void initUserAgent(WebSettings settings)
    {
        /*
         * Mobile: Remove "wv" from the WebView's user agent. Some websites don't work
         * properly if the browser reports itself as a simple WebView.
         * Desktop: Generate the desktop user agent starting from the mobile one so that
         * we always report the current engine version.
         */
        String userAgent = settings.getUserAgentString();
        Pattern pattern = Pattern.compile(PATTERN_USER_AGENT);
        Matcher matcher = pattern.matcher(userAgent);
        if (matcher.matches()) {
            String mobileDevice = matcher.group(2).replace("; wv", "");
            mobileUserAgent = matcher.group(1) + mobileDevice + matcher.group(3);
            desktopUserAgent = matcher.group(1) + DESKTOP_DEVICE + matcher.group(3)
                    .replace(" Mobile ", " ");
            settings.setUserAgentString(mobileDevice);
        } else {
            Log.e(TAG, "Couldn't parse the user agent: " + userAgent);
            mobileUserAgent = settings.getUserAgentString();
            desktopUserAgent = DESKTOP_USER_AGENT_FALLBACK;
        }
    }

    boolean isDesktopMode()
    {
        return isDesktopMode;
    }

    void enableDesktopMode(@NonNull AdvancedWebView webView, boolean enable)
    {
        isDesktopMode = enable;
        WebSettings settings = webView.getSettings();

        settings.setUserAgentString((enable ? desktopUserAgent : mobileUserAgent));
        settings.setUseWideViewPort(enable);
        settings.setLoadWithOverviewMode(enable);
    }


    // Pin website shortcut to launcher
    private void pinShortcut() {
        // Ask for the shortcut title first
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
        builder.setBackground(getDrawable(R.drawable.background_round_corners));
        builder.setTitle(R.string.action_add_shortcut);
        @SuppressLint("InflateParams") View viewInflated = LayoutInflater.from(this).inflate(R.layout.add_shortcut_layout, null);
        final TextInputEditText textInput = viewInflated.findViewById(R.id.TextInput);
        textInput.setText(getCurrentWebView().getTitle());
        builder.setView(viewInflated);

        builder.setPositiveButton(R.string.add, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                // Get the title for the shortcut
                shortcutTitle = (Objects.requireNonNull(textInput.getText()).toString().trim().isEmpty() ?
                        getCurrentWebView().getTitle() : textInput.getText().toString().trim());
                // Create the icon for the shortcut
                createShortcutIcon();
                // Create the shortcut
                Intent pinShortcutIntent = new Intent(BrowserActivity.this, BrowserActivity.class);
                pinShortcutIntent.setData(Uri.parse(getCurrentWebView().getUrl()));
                pinShortcutIntent.setAction(Intent.ACTION_MAIN);
                ShortcutInfoCompat shortcutInfo = new ShortcutInfoCompat.Builder(BrowserActivity.this, shortcutTitle)
                        .setShortLabel(shortcutTitle)
                        .setLongLabel(shortcutTitle)
                        .setIcon(shortcutIcon)
                        .setIntent(pinShortcutIntent)
                        .build();
                ShortcutManagerCompat.requestPinShortcut(BrowserActivity.this, shortcutInfo, null);
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                    snackbarText = getString(R.string.shortcut_added);
                    showSnackbar();
                }
            }
        });
        // Cancel creating shortcut
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        builder.show();
    }

    // Create launcher icons for shortcuts
    private void createShortcutIcon() {
        // Draw background
        Bitmap icon = Bitmap.createBitmap(432, 432, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(icon);
        canvas.drawColor(ContextCompat.getColor(getApplicationContext(), R.color.colorShortcuts));
        // Get the first one or two characters of the shortcut title
        String iconText;
        iconText = (shortcutTitle.length() >= 2 ? shortcutTitle.substring(0, 2) : shortcutTitle.substring(0, 1));
        // Draw the first one or two characters on the background
        Paint paintText = new Paint();
        paintText.setAntiAlias(true);
        paintText.setColor(ContextCompat.getColor(getApplicationContext(), android.R.color.white));
        paintText.setTextSize(128);
        paintText.setFakeBoldText(true);
        paintText.setTextAlign(Paint.Align.CENTER);
        canvas.drawText(iconText, canvas.getWidth() / 2f,
                canvas.getHeight() / 2f - (paintText.descent() + paintText.ascent()) / 2f, paintText);
        // Create icon
        shortcutIcon = IconCompat.createWithAdaptiveBitmap(icon);
    }

    // Show snackbar with custom background and text color
    private void showSnackbar() {
        Snackbar snackbar = Snackbar.make(findViewById(R.id.coordinatorLayout), snackbarText, Snackbar.LENGTH_SHORT);
        View view = snackbar.getView();
        DrawableCompat.setTint(view.getBackground(), ContextCompat.getColor(this, R.color.colorPrimaryVariant));
        TextView textView = view.findViewById(R.id.snackbar_text);
        textView.setTextColor(ContextCompat.getColor(this, R.color.colorText));
        snackbar.show();
    }

    public void PopupWindowTop() {

        LayoutInflater toolsInflater = LayoutInflater.from(getApplicationContext());
        @SuppressLint("InflateParams") View toolsView = toolsInflater.inflate(R.layout.pop_window_tools_top, null);
        toolsPopWindowTop.showAtLocation(toolsView, Gravity.TOP | Gravity.END, 0, tools.getHeight());

        ImageButton goBack = (ImageButton) toolsPopWindowTop.getView(R.id.goBack);
        ImageButton offline_page = (ImageButton) toolsPopWindowTop.getView(R.id.offline_page);
        ImageButton add_bookmarks = (ImageButton) toolsPopWindowTop.getView(R.id.add_bookmarks);
        ImageButton page_info = (ImageButton) toolsPopWindowTop.getView(R.id.page_info);
        LinearLayout action_new_Tab = (LinearLayout) toolsPopWindowTop.getView(R.id.action_new_Tab);
        LinearLayout recent_tabs_deleted = (LinearLayout) toolsPopWindowTop.getView(R.id.recent_tabs_deleted);
        LinearLayout history = (LinearLayout) toolsPopWindowTop.getView(R.id.history);
        LinearLayout download = (LinearLayout) toolsPopWindowTop.getView(R.id.download);
        LinearLayout action_share = (LinearLayout) toolsPopWindowTop.getView(R.id.action_share);
        LinearLayout action_add_shortcut = (LinearLayout) toolsPopWindowTop.getView(R.id.action_add_shortcut);
        LinearLayout help = (LinearLayout) toolsPopWindowTop.getView(R.id.help);
        Switch action_toggle_ad_blocking = (Switch) toolsPopWindowTop.getView(R.id.action_toggle_ad_blocking);
        LinearLayout show_bookmarks = (LinearLayout) toolsPopWindowTop.getView(R.id.show_bookmarks);
        LinearLayout settings = (LinearLayout) toolsPopWindowTop.getView(R.id.settings);
        LinearLayout find_on_page = (LinearLayout) toolsPopWindowTop.getView(R.id.find_on_page);
        Switch desktop_site = (Switch) toolsPopWindowTop.getView(R.id.desktop_site);


        goBack.setOnClickListener(BrowserActivity.this);
        offline_page.setOnClickListener(BrowserActivity.this);
        add_bookmarks.setOnClickListener(BrowserActivity.this);
        page_info.setOnClickListener(BrowserActivity.this);

        action_new_Tab.setOnClickListener(BrowserActivity.this);
        show_bookmarks.setOnClickListener(BrowserActivity.this);
        recent_tabs_deleted.setOnClickListener(BrowserActivity.this);
        history.setOnClickListener(BrowserActivity.this);
        download.setOnClickListener(BrowserActivity.this);
        action_share.setOnClickListener(BrowserActivity.this);
        find_on_page.setOnClickListener(BrowserActivity.this);
        action_add_shortcut.setOnClickListener(BrowserActivity.this);

        ((Switch) toolsPopWindowTop.getView(R.id.desktop_site)).setChecked(isDesktopMode());
        desktop_site.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    enableDesktopMode(getCurrentWebView(), true);
                    getCurrentWebView().reload();
                }else {
                    enableDesktopMode(getCurrentWebView(), false);
                    getCurrentWebView().reload();
                }

            }
        });
        settings.setOnClickListener(BrowserActivity.this);

        ((Switch) toolsPopWindowTop.getView(R.id.action_toggle_ad_blocking)).setChecked(isAdBlockingEnabled);
        action_toggle_ad_blocking.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Toggle ad blocking
                isAdBlockingEnabled = !isAdBlockingEnabled;
                editor = sharedPreferences.edit();
                editor.putBoolean("ad_blocking", isAdBlockingEnabled);
                editor.apply();
                snackbarText = getString(isAdBlockingEnabled ? R.string.ad_blocking_enabled : R.string.ad_blocking_disabled);
                showSnackbar();
                buttonView.setChecked(isAdBlockingEnabled);
                getCurrentWebView().reload();
            }
        });
        help.setOnClickListener(BrowserActivity.this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            // Menu overflow
            case R.id.goBack:
                if (searchTextInput.hasFocus()) {
                    searchTextInput.clearFocus();
                } else if (getCurrentWebView().canGoBack()) {
                        getCurrentWebView().goBack();
                }
                break;
            case R.id.offline_page:

                break;
            case R.id.add_bookmarks:
                final String title = getCurrentWebView().getTitle();
                final String url = getCurrentWebView().getUrl();
                // get image from imageView layout
                //Bitmap image = imageView2Bitmap(tools);

                //OR get image from Drawable
                Bitmap image = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);

                // convert bitmap to byte
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                image.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] imageInByte = stream.toByteArray();
                // Inserting Contacts
                Log.d("Insert: ", "Inserting ..");
                if (Bookmark_Manager.checkUrl(url, BookMark_helper.TABLE_NAME)) {
                    Bookmark_Manager.deleteURL(url, BookMark_helper.TABLE_NAME);
                    Bookmark_Manager.addContact(new Contact(title, url, System.currentTimeMillis(), imageInByte));
                } else {
                    Bookmark_Manager.addContact(new Contact(title, url, System.currentTimeMillis(), imageInByte));
                }

                Toast.makeText(getApplicationContext(), "Bookmark Added", Toast.LENGTH_SHORT).show();
                break;
            case R.id.page_info:
                pageInfo();
                break;
            case R.id.action_new_Tab:
                // Open new Tab
                newTab(startPage);
                switchToTab(Tab.tabs.size() - 1);
                break;
            case R.id.show_bookmarks:
                Intent intent = new Intent();
                intent.setClass(getApplicationContext(), BookmarkActivity.class);
                startActivityForResult(intent, REQUEST_OPEN_FAV);
                break;
            case R.id.recent_tabs_deleted:
                UndoTabs();
                break;
            case R.id.history:
                Intent intent2 = new Intent();
                intent2.setClass(getApplicationContext(), HistoryActivity.class);
                startActivityForResult(intent2, REQUEST_OPEN_HIS);
                break;
            case R.id.download:
                getCurrentWebView().loadHomepage();
                break;
            case R.id.action_share:
                // Share URL
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, getCurrentWebView().getUrl());
                startActivity(Intent.createChooser(shareIntent, getString(R.string.chooser_share)));
                break;
            case R.id.find_on_page:
                findOnPage();
                break;
            case R.id.action_add_shortcut:
                // Pin website shortcut to launcher if supported
                if (ShortcutManagerCompat.isRequestPinShortcutSupported(BrowserActivity.this)) {
                    pinShortcut();
                } else {
                    snackbarText = getString(R.string.shortcuts_not_supported);
                    showSnackbar();
                }
                break;
            case R.id.settings:
                Intent settings = new Intent(getApplicationContext(), SettingsActivity.class);
                startActivity(settings);
                break;
            case R.id.help:

                break;
            case R.id.night_mode:
                toggleNightMode();
                toolsPopWindow.dismiss();
                break;

            default:
                break;
        }
    }


    private void findOnPage() {
        searchEdit.setText("");
        findViewById(R.id.searchPane).setVisibility(View.VISIBLE);
        searchEdit.requestFocus();
        showKeyboard();
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        assert imm != null;
        imm.hideSoftInputFromWindow(searchTextInput.getWindowToken(), 0);
    }

    private void showKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        assert imm != null;
        imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (resultCode) {
            case BrowserActivity.REQUEST_DEFAULT:
                break;

            case HistoryActivity.RESULT_HistoryActivity:
                String url = data.getStringExtra("historyUrl");
                aswm_view(url,false, asw_error_counter, getCurrentWebView());
                break;

            case BookmarkActivity.RESULT_BookmarkActivity:
                String bookmarkUrl = data.getStringExtra("bookmarkUrl");
                aswm_view(bookmarkUrl,false, asw_error_counter, getCurrentWebView());
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
        webview.onActivityResult(requestCode, resultCode, data);
    }

    // slide the view from below itself to the current position
    public void slideUp(RelativeLayout view){

        TranslateAnimation animate = new TranslateAnimation(
                0,                 // fromXDelta
                0,                 // toXDelta
                view.getHeight(),  // fromYDelta
                0);                // toYDelta
        animate.setDuration(500);
        animate.setFillAfter(true);
        view.startAnimation(animate);
        view.setVisibility(View.VISIBLE);
    }

    // slide the view from its current position to below itself
    public void slideDown(RelativeLayout view){

        TranslateAnimation animate = new TranslateAnimation(
                0,                 // fromXDelta
                0,                 // toXDelta
                0,                 // fromYDelta
                view.getHeight()); // toYDelta
        animate.setDuration(500);
        animate.setFillAfter(true);
        view.startAnimation(animate);
        view.setVisibility(View.GONE);
    }

    @Override
    public void onBackPressed() {

        if (searchTextInput.hasFocus()) {
            searchTextInput.clearFocus();
        } else if (getCurrentWebView().canGoBack()) {
                getCurrentWebView().goBack();
        } else if (Tab.tabs.size() > 1) {
            closeCurrentTab();
        } else {
            super.onBackPressed();
        }

    }


    private void bookmark() {

        ArrayList<Contact> imageArry = new ArrayList<>();
        ContactImageAdapter adapter;

        HomePage_helper db = new HomePage_helper(this);

        // display main List view bcard and contact name

        // Reading all contacts from database
        List<Contact> contacts = db.getAllContacts();
        for (Contact cn : contacts) {
            String log = "ID:" + cn.getID() + " Name: " + cn.getName() + " Url: " + cn.getUrl()
                    + " ,Image: " + Arrays.toString(cn.getImage());

            // Writing Contacts to log
            Log.d("Result: ", log);
            //add contacts data in arrayList
            imageArry.add(cn);

        }
        adapter = new ContactImageAdapter(this, R.layout.activity_view_homebookmark,
                imageArry);
        GridView gridView = findViewById(R.id.gridview);
        adapter.notifyDataSetChanged();

        gridView.setAdapter(adapter);

        // OnCLickListiner For List Items
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long viewId) {

                TextView descTextView = view.findViewById(R.id.txtUrl);
                String txtUrl = descTextView.getText().toString();

                if (txtUrl.startsWith("add_more")) {

                    //Intent intent = new Intent();
                    // intent.setClass(Objects.requireNonNull(getActivity()), AddCountryActivity.class);
                    // intent.putExtra("type", "favorite");
                    // startActivityForResult(intent, MainActivity.REQUEST_AddCountryActivity);

                } else if (txtUrl.startsWith("http")) {
                    getCurrentWebView().loadUrl(txtUrl);

                } else {
                    // handle image data
                    String ClickUrl;
                    ClickUrl = "https://" + txtUrl;
                    getCurrentWebView().loadUrl(ClickUrl);
                }
            }
        });

    }




}