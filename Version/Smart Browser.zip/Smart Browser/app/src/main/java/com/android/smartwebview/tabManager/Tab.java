package com.android.smartwebview.tabManager;

import com.android.smartwebview.activity.BrowserActivity;
import com.android.smartwebview.view.AdvancedWebView;

import java.util.ArrayList;

public class Tab {
    public static ArrayList<Tab> tabs = new ArrayList<>();

    public Tab(AdvancedWebView w) {
        this.webview = w;
    }

    public AdvancedWebView webview;
}
