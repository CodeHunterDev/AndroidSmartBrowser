package com.android.smartwebview.history_book;

public class Contact {

	// private variables
	public int _id;
	public String _name;
	public String _url;
	public byte[] _image;
	public long _date;

	// Empty constructor
	public Contact() {

	}

	// constructor
	public Contact(String name, String url, byte[] image) {
		this._name = name;
		this._url = url;
		this._image = image;

	}

	// constructor
	public Contact(String name, String url, long date, byte[] image) {
		this._name = name;
		this._url = url;
		this._image = image;
		this._date = date;

	}

	// getting ID
	public int getID() {
		return this._id;
	}

	// setting id
	public void setID(int keyId) {
		this._id = keyId;
	}

	// getting name
	public String getName() {
		return this._name;
	}

	// setting name
	public void setName(String name) {
		this._name = name;
	}

	// getting url
	public String getUrl() {
		return this._url;
	}

	// setting url
	public void setUrl(String url) {
		this._url = url;
	}

	// getting phone number
	public byte[] getImage() {
		return this._image;
	}

	// setting phone number
	public void setImage(byte[] image) {
		this._image = image;
	}

	public long getDate() {
		return _date;
	}
	public void setDate(long date) {
		this._date = date;
	}

}
