package com.android.smartwebview.utils;

import android.content.Context;
import com.android.smartwebview.R;

public class ThemeUtils {

    private Context mContext;
    public ThemeUtils(Context context){
        mContext = context;
    }
    private static boolean isBlackTheme = false;
    public  void setTheme() {
        PreferenceUtils utils = new PreferenceUtils(mContext);
        switch (utils.getTheme()) {
            case 1:
                mContext.setTheme(R.style.AppTheme2);
                isBlackTheme = false;
                break;
            case 2:
                mContext.setTheme(R.style.AppTheme2Black);
                isBlackTheme = true;
                break;
        }
    }
    public static boolean isBlack(){
        return  isBlackTheme;
    }

}
