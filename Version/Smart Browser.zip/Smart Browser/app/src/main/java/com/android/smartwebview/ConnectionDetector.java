package com.android.smartwebview;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class ConnectionDetector {

	private Context mContext;
     
    public ConnectionDetector(Context context){
        this.mContext = context;
    }
 
    public boolean isConnectingToInternet(){

		ConnectivityManager cm =
				(ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
		assert cm != null;
		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		Boolean offline_app = Config.offline_app;
		return (activeNetwork != null && activeNetwork.isConnected()) || offline_app;

	}
}