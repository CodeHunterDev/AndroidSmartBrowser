package com.android.smartwebview.activity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;

import com.android.smartwebview.history_book.Contact;
import com.android.smartwebview.sqliteasset.SQLiteAssetHelper;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.List;

public class HomePage_helper extends SQLiteAssetHelper {

    // Database Name
    private static final String DATABASE_NAME = "BookMark_HomePage.db";
    // Contacts table name
    private static final String TABLE_NAME = "list";

    // Contacts Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_URL = "url";
    private static final String KEY_IMAGE = "image";

    // Creating table query
    private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "("
            + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT NOT NULL, " + KEY_URL + " TEXT, " + KEY_IMAGE + " BLOB" + ")";

    // database version
    static final int DB_VERSION = 1;

    public HomePage_helper(Context context) {
        super(context, DATABASE_NAME, null, DB_VERSION);

    }

    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */

    public void addContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, contact._name); // Contact Name
        values.put(KEY_URL, contact._url); // Contact Url
        values.put(KEY_IMAGE, contact._image); // Contact Phone

        // Inserting Row
        db.insert(TABLE_NAME, null, values);
        db.close(); // Closing database connection
    }


    // Getting All Contacts
    public List<Contact> getAllContacts() {
        List<Contact> contactList = new ArrayList<Contact>();
        // Select All Query
        String selectQuery = "SELECT  * FROM list ORDER BY id";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Contact contact = new Contact();
                contact.setID(Integer.parseInt(cursor.getString(0)));
                contact.setName(cursor.getString(1));
                contact.setUrl(cursor.getString(2));
                contact.setImage(cursor.getBlob(3));
                // Adding contact to list
                contactList.add(contact);
            } while (cursor.moveToNext());
        }
        // close inserting data from database
        db.close();
        // return contact list
        return contactList;

    }

    // Updating single contact
    public int updateContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, contact.getName());
        values.put(KEY_URL, contact.getUrl());
        values.put(KEY_IMAGE, contact.getImage());

        // updating row
        return db.update(TABLE_NAME, values, KEY_ID + " = ?",
                new String[] { String.valueOf(contact.getID()) });

    }

    // Deleting single contact
    public void delete(long _id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, KEY_ID + "=" + _id, null);
        db.close();
    }


    // Getting contacts Count
    public int getContactsCount() {
        String countQuery = "SELECT  * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        // return count
        return cursor.getCount();
    }



}
